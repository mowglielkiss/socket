/* CHANGES FROM UNIX VERSION                                                   */
/*                                                                             */
/* 1.  Changed header files.                                                   */
/* 2.  Added WSAStartUP() and WSACleanUp().                                    */
/* 3.  Used closesocket() instead of close().                                  */ 

#include <stdio.h>      /* for printf(), fprintf() */
#include <winsock.h>    /* for socket(),... */
#include <stdlib.h>     /* for exit() */
#include <stdint.h>
#include <QString>

#include <QThread>

#define RCVBUFSIZE 4096   /* Size of receive buffer */

// forward declaration: don't need headerfile.
//void DieWithError(const char *errorMessage);  /* Error handling function */
void DieWithError(QString errorMessage);


void CloseSocket(int sock)
{
    printf("closeSocket.");
    closesocket(sock);
}
int CreateSocket()
{
    int sock;
    printf("CreateSocket.");
    if ((sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
        printf("socket() failed\n");
    }
    return sock;
}
int ReConnetSocket(int sock)
{
    CloseSocket(sock);
    return CreateSocket();
}

void main_process(int argc, const char *argv[])
{
    int sock;                        /* Socket descriptor */
    struct sockaddr_in echoServAddr; /* Echo server address */
    unsigned short echoServPort;     /* Echo server port */
    char *servIP;                    /* Server IP address (dotted quad) */
    char *echoString;                /* String to send to echo server */
    char echoBuffer[RCVBUFSIZE];     /* Buffer for echo string */
    char sendBuffer[RCVBUFSIZE];
    int64_t echoStringLen;               /* Length of string to echo */
    int64_t SendStringLen;
    int bytesRcvd, totalBytesRcvd;   /* Bytes read in single recv() and total bytes read */
    WORD wVersionRequested;          /* Version of Winsock to load */
    WSADATA wsaData;                 /* Winsock implementation details */

    int sendCount = 1;

    if ((argc < 3) || (argc > 4))    /* Test for correct number of arguments */
    {
        fprintf(stderr, "Usage: %s <Server IP> <Echo Word> [<Echo Port>]\n", argv[0]);
        exit(1);
    }

    servIP = const_cast<char *>(argv[1]);             /* first arg: server IP address (dotted quad) */
    echoString = const_cast<char *>(argv[2]);         /* second arg: string to echo */

    if (argc == 4)
        echoServPort = atoi(argv[3]); /* Use given port, if any */
    else
        echoServPort = 7;  /* otherwise, 7 is the well-known port for the echo service */

    wVersionRequested = MAKEWORD(2, 0);   /* Request Winsock v2.0 */
    if (WSAStartup(wVersionRequested, &wsaData) != 0) /* Load Winsock DLL */
    {
        fprintf(stderr,"WSAStartup() failed");
        exit(1);
    }

    /* Create a reliable, stream socket using TCP */
    if ((sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
        printf("socket() failed\n");
    }

//    /* Construct the server address structure */
    memset(&echoServAddr, 0, sizeof(echoServAddr));     /* Zero out structure */
    echoServAddr.sin_family      = AF_INET;             /* Internet address family */
    echoServAddr.sin_addr.s_addr = inet_addr(servIP);   /* Server IP address */
    echoServAddr.sin_port        = htons(echoServPort); /* Server port */
    while (1)
    {
        /* Establish the connection to the echo server */
        printf("Try connect.\n");
        if (connect(sock, (struct sockaddr *) &echoServAddr, sizeof(echoServAddr)) < 0) {
            printf("connect() failed\n");
            CloseSocket(sock);
            sock = CreateSocket();
            printf("wait 5 sec\n");
            QThread::msleep(5 * 1000);
            continue;
        }
        printf("OK. connected.\n");
        echoStringLen = strlen(echoString) + 1;          /* Determine input length */

        while (1) {
            printf("===== Send Interval 5 sec\n");
            QThread::msleep(5 * 1000);
            /* Send the string, including the null terminator, to the server */
            memset(&sendBuffer, 0, sizeof(sendBuffer));
            sprintf(sendBuffer, "---(%d)th (%s)", sendCount, echoString);
            SendStringLen = strlen(sendBuffer) + 1; //  + NULL
            printf("send Data.[%s][%lld]\n", sendBuffer, SendStringLen);
            if (send(sock, sendBuffer, SendStringLen, 0) != SendStringLen) {
                printf("send() sent a different number of bytes than expected\n");
            }
            ++sendCount;

            /* Receive the same string back from the server */
            totalBytesRcvd = 0;
            printf("Received:\n");                /* Setup to print the echoed string */
            while (totalBytesRcvd < SendStringLen)
            {
                /* Receive up to the buffer size (minus 1 to leave space for
                   a null terminator) bytes from the sender */
                printf("  (in while)recv()\n");
                if ((bytesRcvd = recv(sock, echoBuffer, RCVBUFSIZE - 1, 0)) < 0) {
                    printf("recv() failed or connection closed prematurely. Try Connect Again.\n");
                    break;
                }
                totalBytesRcvd += bytesRcvd;   /* Keep tally of total bytes */
                echoBuffer[bytesRcvd] = '\0';  /* Add \0 so printf knows where to stop */
            }
            printf("Fin. Received:%s[%d]\n", echoBuffer, strlen(echoBuffer));            /* Print the echo buffer */
            // compare sendBuffer to echoBuffer
            if (0 == strcmp(sendBuffer, echoBuffer)) {
                printf("Same. compare sendBuffer to echoBuffer\n");
            } else {
                printf("NG. compare. Server Dead. Try connect again.\n");
                break;
            }

        }

    }

    printf("\n");    /* Print a final linefeed */

    printf("CLIENT: closesocket(sock)\n");
    closesocket(sock);
    printf("CLIENT: WSACleanup()\n");
    WSACleanup();  /* Cleanup Winsock */
    printf("CLIENT: DEBUG while(1)\n");
    while (1) {
        printf("wait 10 sec\n");
        QThread::msleep(10 * 1000);
    }

    //exit(0);
}

// case 1.  run Client -> run Server  : 1st OK, 2nd NG
