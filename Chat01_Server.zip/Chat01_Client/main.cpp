#include <QCoreApplication>

// forward declaration: don't need headerfile.
void main_process(int argc, const char *argv[]);

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    const char arg1[] = "main app";
    const char arg2[] = "127.0.0.1";
    const char arg3[] = "um hosang";
    const char arg4[] = "5000";
    const char* argvtcp[4];
    argvtcp[0] = arg1;
    argvtcp[1] = arg2;
    argvtcp[2] = arg3;
    argvtcp[3] = arg4;


    main_process(4, argvtcp);

    return a.exec();
}
